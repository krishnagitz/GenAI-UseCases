import logging

def setup_logging():
    logging.getLogger().setLevel(logging.ERROR)
